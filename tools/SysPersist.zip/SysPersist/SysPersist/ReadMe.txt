========================================================================
    CONSOLE APPLICATION : SysPersist Project Overview
========================================================================

A SYSTEM persistence service that binds a command shell with SYSTEM 
privileges on loopback interface port 1337.