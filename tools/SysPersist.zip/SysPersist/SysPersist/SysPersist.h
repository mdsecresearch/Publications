#pragma once

class CServiceBase
{
public:
	static BOOL Run(CServiceBase &service);
	CServiceBase(PWSTR pszServiceName, BOOL fCanStop = TRUE, BOOL fCanShutdown = TRUE, BOOL fCanPauseContinue = FALSE);
	virtual ~CServiceBase(void);
	void Stop();
protected:
	virtual void OnStart(DWORD dwArgc, PWSTR *pszArgv);
	virtual void OnStop();
	virtual void OnPause();
	virtual void OnContinue();
	virtual void OnShutdown();
	void SetServiceStatus(DWORD dwCurrentState, DWORD dwWin32ExitCode = NO_ERROR, DWORD dwWaitHint = 0);
private:
	static void WINAPI ServiceMain(DWORD dwArgc, LPWSTR *lpszArgv);
	static void WINAPI ServiceCtrlHandler(DWORD dwCtrl);
	void Start(DWORD dwArgc, PWSTR *pszArgv);
	void Pause();
	void Continue();
	void Shutdown();
	static CServiceBase *s_service;
	PWSTR m_name;
	SERVICE_STATUS m_status;
	SERVICE_STATUS_HANDLE m_statusHandle;
};


class CSystemPersistService : public CServiceBase
{
public:
	CSystemPersistService(PWSTR pszServiceName, BOOL fCanStop = TRUE, BOOL fCanShutdown = TRUE, BOOL fCanPauseContinue = FALSE);
	virtual ~CSystemPersistService(void);
protected:
	virtual void OnStart(DWORD dwArgc, PWSTR *pszArgv);
	virtual void OnStop();
	void ServiceWorkerThread(void);
private:
	BOOL m_fStopping;
	HANDLE m_hStoppedEvent;
};

void InstallService(PWSTR pszServiceName, PWSTR pszDisplayName, DWORD dwStartType, PWSTR pszDependencies, PWSTR pszAccount, PWSTR pszPassword);
void UninstallService(PWSTR pszServiceName);

class CThreadPool
{
public:
	template <typename T>
	static void QueueUserWorkItem(void (T::*function)(void), T *object, ULONG flags = WT_EXECUTELONGFUNCTION)
	{
		typedef std::pair<void (T::*)(), T *> CallbackType;
		std::auto_ptr<CallbackType> p(new CallbackType(function, object));
		if (::QueueUserWorkItem(ThreadProc<T>, p.get(), flags))
		{
			p.release();
		}
		else
		{
			throw GetLastError();
		}
	}
private:
	template <typename T>
	static DWORD WINAPI ThreadProc(PVOID context)
	{
		typedef std::pair<void (T::*)(), T *> CallbackType;
		std::auto_ptr<CallbackType> p(static_cast<CallbackType *>(context));
		(p->second->*p->first)();
		return 0;
	}
};