// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently

#pragma once
#include "targetver.h"
#include <stdio.h>
#include <tchar.h>
#include <wchar.h>
#include <winsock2.h>
#include <windows.h>
#include <assert.h>
#include <strsafe.h>
#include <memory>
#include "SysPersist.h"

#pragma comment(lib,"Ws2_32.lib")
